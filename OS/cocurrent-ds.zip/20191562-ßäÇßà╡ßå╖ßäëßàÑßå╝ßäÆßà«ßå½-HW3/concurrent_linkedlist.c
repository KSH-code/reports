#include <pthread.h>
#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>

#define THREADS_COUNT 12
// gcc concurrent_linkedlist.c -o concurrent_linkedlist -lpthread && ./concurrent_linkedlist
// running time: 0.061087s
// running time: 0.120078s
// running time: 0.186377s
// running time: 0.268855s
// running time: 0.320492s

// basic node structure
typedef struct __node_t
{
  int key;
  struct __node_t *next;
} node_t;
// basic list structure (one used per list)
typedef struct __list_t
{
  node_t *head;
  pthread_mutex_t lock;
  int updates_count;
} list_t;
void List_Init(list_t *L, int i)
{
  L->head = malloc(sizeof(node_t));
  L->updates_count = i * 10000;
  pthread_mutex_init(&L->lock, NULL);
}
void List_Insert(list_t *L, int index, int key)
{
  // synchronization not needed
  node_t *new = malloc(sizeof(node_t));
  if (new == NULL)
  {
    perror("malloc");
    return;
  }
  new->key = key;
  // just lock critical section
  pthread_mutex_lock(&L->lock);
  node_t *cur = L->head;
  for (int i = 0; i < index; i++)
  {
    cur = cur->next;
  }
  new->next = cur->next;
  cur->next = new;
  pthread_mutex_unlock(&L->lock);
}

int *insert(list_t *l)
{
  for (int i = 0; i < l->updates_count; i++)
    List_Insert(l, i % 100, i);
  return 0;
}

int main(void)
{
  for (int i = 1; i <= 5; i++)
  {
    list_t *list = malloc(sizeof(list_t));
    List_Init(list, i);
    struct timeval start_time;
    struct timeval end_time;
    pthread_t p_thread[THREADS_COUNT];
    gettimeofday(&start_time, NULL);
    for (int i = 0; i < THREADS_COUNT; i++)
    {
      pthread_create(&p_thread[i], NULL, (void *)insert, (void *)list);
    }
    for (int i = 0; i < THREADS_COUNT; i++)
    {
      pthread_join(p_thread[i], NULL);
    }
    gettimeofday(&end_time, NULL);
    double running_time = end_time.tv_sec - start_time.tv_sec + (end_time.tv_usec - start_time.tv_usec) / 1000000.0;
    printf("running time: %fs\n", running_time);
  }
  return 0;
}
