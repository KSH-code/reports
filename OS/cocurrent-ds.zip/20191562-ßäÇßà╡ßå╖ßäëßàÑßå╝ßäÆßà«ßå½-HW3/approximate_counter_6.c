#include <pthread.h>
#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>

// gcc approximate_counter_6.c -o approximate_counter_6 -lpthread && ./approximate_counter_6
// result: 14400000
// running time: 0.761610s
#define NUMCPUS 6
typedef struct __counter_t
{
  int global;                     // global count
  pthread_mutex_t glock;          // global lock
  int local[NUMCPUS];             // per-CPU count
  pthread_mutex_t llock[NUMCPUS]; // ... and locks
  int threshold;                  // update frequency
} counter_t;

typedef struct __counter_tc
{
  counter_t *c;
  int thread_id;
} counter_tc;

// init: record threshold, init locks, init values
// of all local counts and global count
void init(counter_t *c, int threshold)
{
  c->threshold = threshold;
  c->global = 0;
  pthread_mutex_init(&c->glock, NULL);
  int i;
  for (i = 0; i < NUMCPUS; i++)
  {
    c->local[i] = 0;
    pthread_mutex_init(&c->llock[i], NULL);
  }
}

// update: usually, just grab local lock and update
// local amount; once local count has risen ’threshold’,
// grab global lock and transfer local values to it
void update(counter_t *c, int threadID, int amt)
{
  int cpu = threadID % NUMCPUS;
  pthread_mutex_lock(&c->llock[cpu]);
  c->local[cpu] += amt;
  if (c->local[cpu] >= c->threshold)
  {
    // transfer to global (assumes amt>0)
    pthread_mutex_lock(&c->glock);
    c->global += c->local[cpu];
    pthread_mutex_unlock(&c->glock);
    c->local[cpu] = 0;
  }
  pthread_mutex_unlock(&c->llock[cpu]);
}

// get: just return global amount (approximate)
int get(counter_t *c)
{
  pthread_mutex_lock(&c->glock);
  int val = c->global;
  pthread_mutex_unlock(&c->glock);
  return val; // only approximate!
}

int *run_count_updateing(counter_tc *c)
{
  for (int i = 0; i < 2400000; i++)
  {
    update(c->c, c->thread_id, 1);
  }
  return 0;
}

int main(void)
{
  counter_t *counter = malloc(sizeof(counter_t));
  init(counter, 1024);
  struct timeval start_time;
  struct timeval end_time;
  pthread_t p_thread[NUMCPUS];
  gettimeofday(&start_time, NULL);
  for (int i = 0; i < NUMCPUS; i++)
  {
    counter_tc *tc = malloc(sizeof(counter_tc));
    tc->c = counter;
    tc->thread_id = i;
    pthread_create(&p_thread[i], NULL, (void *)run_count_updateing, (void *)tc);
  }
  for (int i = 0; i < NUMCPUS; i++)
  {
    pthread_join(p_thread[i], NULL);
  }

  // Note: Since it is not updated when local count does not reach threshold, must set threshold to 0 and call update method.
  counter->threshold = 0;
  for (int i = 0; i < NUMCPUS; i++)
  {
    update(counter, i, 0);
  }
  gettimeofday(&end_time, NULL);
  printf("result: %d\n", get(counter));
  double running_time = end_time.tv_sec - start_time.tv_sec + (end_time.tv_usec - start_time.tv_usec) / 1000000.0;
  printf("running time: %fs\n", running_time);
  return 0;
}
