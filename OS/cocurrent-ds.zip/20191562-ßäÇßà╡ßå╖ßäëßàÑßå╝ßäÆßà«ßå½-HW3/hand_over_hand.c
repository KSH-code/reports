#include <pthread.h>
#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>

#define THREADS_COUNT 12
// gcc hand_over_hand.c -o hand_over_hand -lpthread && ./hand_over_hand
// running time: 0.021257s
// running time: 0.037396s
// running time: 0.057300s
// running time: 0.078014s
// running time: 0.106378s

// basic node structure
typedef struct __node_t
{
  int key;
  struct __node_t *next;
  pthread_mutex_t lock;
} node_t;

typedef struct __list_t
{
  node_t *head;
  int updates_count;
} list_t;
void List_Init(list_t *L, int i)
{
  L->head = malloc(sizeof(node_t));
  L->updates_count = i * 10000;
}
void List_Insert(list_t *L, int index, int key)
{
  // synchronization not needed
  node_t *new = malloc(sizeof(node_t));
  if (new == NULL)
  {
    perror("malloc");
    return;
  }
  pthread_mutex_init(&new->lock, NULL);
  new->key = key;

  pthread_mutex_t f_lock = L->head->lock;
  pthread_mutex_t s_lock;
  pthread_mutex_lock(&f_lock);
  node_t *cur = L->head;
  for (int i = 0; i < index; i++)
  {
    s_lock = cur->next->lock;
    pthread_mutex_lock(&s_lock);
    cur = cur->next;
    pthread_mutex_unlock(&f_lock);
    f_lock = s_lock;
  }
  new->next = cur->next;
  cur->next = new;
  pthread_mutex_unlock(&f_lock);
}

int *insert(list_t *l)
{
  for (int i = 0; i < l->updates_count; i++)
    List_Insert(l, i % 100, i);
  return 0;
}

int main(void)
{
  for (int i = 1; i <= 5; i++)
  {
    list_t *list = malloc(sizeof(list_t));
    List_Init(list, i);
    struct timeval start_time;
    struct timeval end_time;
    pthread_t p_thread[THREADS_COUNT];
    gettimeofday(&start_time, NULL);
    for (int i = 0; i < THREADS_COUNT; i++)
    {
      pthread_create(&p_thread[i], NULL, (void *)insert, (void *)list);
    }
    for (int i = 0; i < THREADS_COUNT; i++)
    {
      pthread_join(p_thread[i], NULL);
    }
    gettimeofday(&end_time, NULL);
    double running_time = end_time.tv_sec - start_time.tv_sec + (end_time.tv_usec - start_time.tv_usec) / 1000000.0;
    printf("running time: %fs\n", running_time);
  }
  return 0;
}
