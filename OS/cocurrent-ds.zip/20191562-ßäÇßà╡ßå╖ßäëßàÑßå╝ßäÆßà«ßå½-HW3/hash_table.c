#include <pthread.h>
#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>

#define THREADS_COUNT 12
#define BUCKETS (101)

// gcc hash_table.c -o hash_table -lpthread && ./hash_table
// running time: 0.008672s
// running time: 0.014772s
// running time: 0.022915s
// running time: 0.029409s
// running time: 0.036158s

// basic node structure
typedef struct __node_t
{
  int key;
  struct __node_t *next;
} node_t;
// basic list structure (one used per list)
typedef struct __list_t
{
  node_t *head;
  pthread_mutex_t lock;
} list_t;
typedef struct __hash_t
{
  list_t lists[BUCKETS];
  int updates_count;
} hash_t;
void List_Init(list_t *L)
{
  L->head = malloc(sizeof(node_t));
  pthread_mutex_init(&L->lock, NULL);
}
void List_Insert(list_t *L, int index, int key)
{
  // synchronization not needed
  node_t *new = malloc(sizeof(node_t));
  if (new == NULL)
  {
    perror("malloc");
    return;
  }
  new->key = key;
  // just lock critical section
  pthread_mutex_lock(&L->lock);
  node_t *cur = L->head;
  for (int i = 0; i < index; i++)
  {
    if (cur->next)
      cur = cur->next;
  }
  new->next = cur->next;
  cur->next = new;
  pthread_mutex_unlock(&L->lock);
}

void Hash_Init(hash_t *H, int j)
{
  int i;
  H->updates_count = j * 10000;
  for (i = 0; i < BUCKETS; i++)
    List_Init(&H->lists[i]);
}
void Hash_Insert(hash_t *H, int key)
{
  List_Insert(&H->lists[key % BUCKETS], key % 100, key);
}
int *insert(hash_t *h)
{
  for (int i = 0; i < h->updates_count; i++)
    Hash_Insert(h, i);
  return 0;
}

int main(void)
{
  for (int i = 1; i <= 5; i++)
  {
    hash_t *hash = malloc(sizeof(hash_t));
    Hash_Init(hash, i);
    struct timeval start_time;
    struct timeval end_time;
    pthread_t p_thread[THREADS_COUNT];
    gettimeofday(&start_time, NULL);
    for (int i = 0; i < THREADS_COUNT; i++)
    {
      pthread_create(&p_thread[i], NULL, (void *)insert, (void *)hash);
    }
    for (int i = 0; i < THREADS_COUNT; i++)
    {
      pthread_join(p_thread[i], NULL);
    }
    gettimeofday(&end_time, NULL);
    double running_time = end_time.tv_sec - start_time.tv_sec + (end_time.tv_usec - start_time.tv_usec) / 1000000.0;
    printf("running time: %fs\n", running_time);
  }
  return 0;
}
