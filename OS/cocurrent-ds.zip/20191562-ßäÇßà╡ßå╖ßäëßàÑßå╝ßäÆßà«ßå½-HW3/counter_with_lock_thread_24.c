#include <pthread.h>
#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>

// gcc counter_with_lock_thread_24.c -o counter_with_lock_thread_24 -lpthread && ./counter_with_lock_thread_24
// result: 57600000
// running time: 3.634974s

int THREADS_COUNT = 24;

typedef struct __counter_t
{
  int value;
  pthread_mutex_t lock;
} counter_t;

void init(counter_t *c)
{
  c->value = 0;
  pthread_mutex_init(&c->lock, NULL);
}

void increment(counter_t *c)
{
  pthread_mutex_lock(&c->lock);
  c->value++;
  pthread_mutex_unlock(&c->lock);
}

int get(counter_t *c)
{
  pthread_mutex_lock(&c->lock);
  int rc = c->value;
  pthread_mutex_unlock(&c->lock);
  return rc;
}

int *run_count_updateing(counter_t *c)
{
  for (int i = 0; i < 2400000; i++)
  {
    increment(c);
  }
  return 0;
}

int main(void)
{
  counter_t *counter = malloc(sizeof(counter_t));
  init(counter);
  struct timeval start_time;
  struct timeval end_time;
  pthread_t p_thread[THREADS_COUNT];
  gettimeofday(&start_time, NULL);
  for (int i = 0; i < THREADS_COUNT; i++)
  {
    pthread_create(&p_thread[i], NULL, (void *)run_count_updateing, (void *)counter);
  }
  for (int i = 0; i < THREADS_COUNT; i++)
  {
    pthread_join(p_thread[i], NULL);
  }
  gettimeofday(&end_time, NULL);
  printf("result: %d\n", get(counter));
  double running_time = end_time.tv_sec - start_time.tv_sec + (end_time.tv_usec - start_time.tv_usec) / 1000000.0;
  printf("running time: %fs", running_time);
  return 0;
}
